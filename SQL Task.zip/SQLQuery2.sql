

create database Academy; 
go
USE Academy;
go

create table Grup
(
   Id int primary key identity(1,1),
   Name nvarchar(10) not null check(Name<>'') unique ,
   Rating int NOT NULL check(Rating Between 1 and 5),
   Year int not null check(Year between 1 and 5),
);
go
insert into Grup(Name,Rating,Year)
values  ('12BD',4,3),
        ('11AA',4,5),
		('1CD',3,5),
		('13FD',5,1);
		go
create table Department
(
   Id int primary key identity(1,1),
   Financing money not null default(0) check(Financing>=0),
   Name nvarchar(100) not null check(Name<>'') unique,
);
go
insert into Department(Financing,Name)
values (20000,'Web Development'),
       (30000,'collection development'),
	   (15000,'government documents'),
	   (21000,'administration');
	   go
create table Faculties
(
   Id int primary key identity(1,1),
   Dean nvarchar(max) not null Check(Dean<>''),
   Name nvarchar(100) not null check(Name<>'') unique,
);
go
insert into Faculties(Dean,Name)
values ('Bob','Department of Geography'),
       ('Greg','Department of Anesthesiology'),
	   ('Steev','Department of Sociology'),
	   ('OcKorner','Department of Industrial Relations');
	   go
create table Teacher
(
   Id int primary key identity(1,1),
   EmploymentDate date not null check(EmploymentDate>='01.01.1990' ),
   Name nvarchar(100) not null check(Name<>'') unique,
   Premium money not null default(0) check(Premium>=0),
   Salary money not null check(Salary>=1),
   Surname nvarchar(max) not null check(Surname<>''),
   IsAsistent bit not null default(0),
   IsProfessor bit not null default(0),
   Position nvarchar(max) not null check(Position<>''),
);
go
insert into Teacher (EmploymentDate , Name, Premium, Salary, Surname, IsAsistent, IsProfessor, Position) values ('10/11/2016', 'Abigail', 440, 6804, 'Pavlenkov', 0, 1, 'Browseblab');
insert into Teacher (EmploymentDate , Name, Premium, Salary, Surname, IsAsistent, IsProfessor, Position) values ('6/4/2008', 'Babbette', 9603, 3138, 'Dietzler', 0, 1, 'Kimia');
insert into Teacher (EmploymentDate , Name, Premium, Salary, Surname, IsAsistent, IsProfessor, Position) values ('10/27/2010', 'Donnie', 230, 8341, 'Herrema', 1, 0, 'Mybuzz');
insert into Teacher (EmploymentDate , Name, Premium, Salary, Surname, IsAsistent, IsProfessor, Position) values ('10/2/1998', 'Birdie', 4241, 4399, 'Molyneux', 1, 0, 'Jetwire');
go

--1. Вывести таблицу кафедр, но расположить ее поля в обратном порядке.
select * from Department
order by id Desc

--2. Вывести названия групп и их рейтинги, используя в качестве названий выводимых полей “Group Name” и “Group
--Rating” соответственно.
select name,Rating
from Grup

--3. Вывести для преподавателей их фамилию, процент ставки
--по отношению к надбавке и процент ставки по отношению
--к зарплате (сумма ставки и надбавки).
select Surname,(Premium/Salary*100),(Salary/Premium*100) 
from Teacher

--4. Вывести таблицу факультетов в виде одного поля в следующем формате: “The dean of faculty [faculty] is [dean].”
select Name,Dean From Faculties 

--5. Вывести фамилии преподавателей, которые являются профессорами и ставка которых превышает 1050.
select *from Teacher
where IsProfessor=1 and Salary>=1050

--6. Вывести названия кафедр, фонд финансирования которых
--меньше 11000 или больше 25000.
select * from Department
where Financing<=11000 or Financing>=25000

--7. Вывести названия факультетов кроме факультета “Computer
--Science”
select Name from Faculties
where Name<>'Department of Geography'
--8. Вывести фамилии и должности преподавателей, которые
--не являются профессорами.select Surname, Position From Teacherwhere IsProfessor=0--9. Вывести фамилии, должности, ставки и надбавки ассистентов, у которых надбавка в диапазоне от 160 до 550.select Surname,Position,Premium from Teacherwhere IsAsistent=1 and Premium between 160 and 550--10.Вывести фамилии и ставки ассистентов.select Surname, Salary from Teacherwhere IsAsistent=1--11.Вывести фамилии и должности преподавателей, которые
--были приняты на работу до 01.01.2000.select Surname,Position from Teacherwhere EmploymentDate<='01.01.2000'--12.Вывести названия кафедр, которые в алфавитном порядке
--располагаются до кафедры “Software Development”. Выводимое поле должно иметь название “Name of Department”.--13.Вывести фамилии ассистентов, имеющих зарплату (сумма
--ставки и надбавки) не более 1200.
select Surname from Teacher
where IsAsistent=1 and (Premium+Salary)<=4000


--14.Вывести названия групп 5-го курса, имеющих рейтинг
--в диапазоне от 2 до 4.select Name from Grupwhere Year=3 and Rating between 2 and 4--15.Вывести фамилии ассистентов со ставкой меньше 550 или
--надбавкой меньше 200.select Surname from Teacherwhere IsAsistent=1 and Salary<3000 or Premium<3000